public function single($title)
{
    $posts = Post::where('title', $title)->get();

    $comments = Comment::where([
        ['post_id', 7],
        ['verify',1]
    ])->orderBy('id', 'desc')->get();
    return view('main.single', compact('posts', 'comments'));
}