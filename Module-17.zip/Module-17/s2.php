/**
 * @var $posts
 * @return Illuminate\Database\Eloquent\Collection
**/
 
$posts Post::get('title', 'description');
 
return $posts;


 
/**
 * @var $posts
 * @return Illuminate\Support\Collection
**/
 
$posts Post::pluck('title', 'description');
 
// ['title' => 'description'] returns a key => value
 
return $posts;